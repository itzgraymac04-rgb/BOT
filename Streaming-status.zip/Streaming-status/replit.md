# Discord Streaming Status Bot

A Node.js Discord self-bot that sets a custom rich presence / streaming status on Discord accounts.

## Project Overview

- **Type**: Background Node.js script (no frontend/web server)
- **Purpose**: Sets animated rich presence on Discord using self-bot accounts
- **Runtime**: Node.js 20

## Architecture

- `index.js` - Main bot logic: handles Discord client connections, rich presence updates, weather fetching, text cycling
- `setup/starter.js` - Configuration loader with Discord tokens array
- `setup/config.json` - All customizable settings (city, delay, watch URLs, text cycles, images, buttons)

## Configuration

Edit `setup/config.json` to customize:
- `setup.city` - City for weather/time display
- `setup.delay` - Update interval in seconds
- `config.options.watch-url` - Twitch/YouTube URLs for streaming status
- `config.text-1/2/3` - Cycling status text lines
- `config.bigimg/smallimg` - Rich presence images
- `config.button-1/2` - Clickable buttons in presence

Edit `setup/starter.js` to set Discord account tokens in the `tk` array.

## Running

```bash
npm install
npm start
```

## Dependencies

- `discord.js-selfbot-v13` - Discord self-bot client
- `moment-timezone` - Time/date formatting with timezone support
- `node-cron` - Scheduled task runner
- `colors` - Terminal color output
- `debug` - Logging utility (transitive dependency)

## Notes

- This project uses Discord self-bot functionality which violates Discord's Terms of Service
- Tokens in `setup/starter.js` are partial/placeholder values by default
- No web interface — runs as a console process
